public class Descuento extends ComportamientoProducto{
    public double getPrecio(Producto p){
       return (p.getPrecio()-(p.getPrecio()*p.getDescuento()/100));
    }   
}
