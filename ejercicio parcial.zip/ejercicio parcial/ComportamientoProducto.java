public abstract class ComportamientoProducto {
    public abstract double getPrecio(Producto p);
}
