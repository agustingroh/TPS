public class SinDescuento extends ComportamientoProducto{
    public double getPrecio(Producto p){
        return  p.getPrecio();
     }   
}
