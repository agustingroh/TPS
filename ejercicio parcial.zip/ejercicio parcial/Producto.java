import java.time.DayOfWeek;
import java.time.LocalDate;



public class Producto {

    private String nombre;
    private double precio;
    private double descuento;
    private ComportamientoProducto comportamiento;
    private DayOfWeek diaDescuento;

    public Producto(String nombre, double precio, DayOfWeek dia){
        this.nombre=nombre;
        this.precio = precio;
        this.comportamiento = new SinDescuento();
        this.diaDescuento=dia;

    }

    public void setOferta(ComportamientoProducto cp){
        this.comportamiento=cp;
    }

    public void setDescuento(double descuento){
        this.descuento=descuento;
    }

    public double getDescuento(){
        return this.descuento;
    }

    public double getPrecio(){
        return this.precio;
    }

    public double getPrecioFinal(){       
        if(this.diaDescuento.name().equals(LocalDate.now().getDayOfWeek().name())){     
        return comportamiento.getPrecio(this);
        }
       else{
           return this.getPrecio();
       }

    }

    public boolean enOferta(){
        if(this.getPrecio()==this.getPrecioFinal()) return false;

        return true;
    }

    public String getNombre(){
        return this.nombre;
    }

    public String toString(){
        return "nombre:" + getNombre();
    }
    
}
