public abstract class Exigencia {
    

    public abstract boolean exigencia(Lote l, Cereal c);

}
